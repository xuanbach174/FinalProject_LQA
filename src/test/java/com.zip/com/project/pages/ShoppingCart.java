package com.project.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ShoppingCart extends Base {
	By PROCEED_CHECKOUT =  By.xpath("//*[@class=\"cart_navigation clearfix\"]/*[@title=\"Proceed to checkout\"]");
	By TOTAL_PRODUCTS_PRICE = By.xpath("//*[@id=\"total_product\"]");
	public ShoppingCart(WebDriver driver) {
		this.driver = driver;
	}
	
	public AddPage checkOut() {
		driver.findElement(PROCEED_CHECKOUT).click();
		return new AddPage(driver);
	}
	
	public String getValuePrice() {
		String total_price = driver.findElement(TOTAL_PRODUCTS_PRICE).getText();
		String value_of_total_price = super.getNumberFromString(total_price);
		return value_of_total_price;
	}
	
}
