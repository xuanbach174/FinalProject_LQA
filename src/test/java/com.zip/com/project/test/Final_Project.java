package com.project.test;

import org.testng.annotations.Test;

import com.project.pages.AccountCreationPage;
import com.project.pages.AddPage;
import com.project.pages.ContactNotifPage;
import com.project.pages.ContactPage;
import com.project.pages.DataTestDTO;
import com.project.pages.Homepage;
import com.project.pages.Login;
import com.project.pages.MyAccount;
import com.project.pages.PaymentMethodPage;
import com.project.pages.SearchResultPage;
import com.project.pages.ShipPage;
import com.project.pages.ShoppingCart;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import static org.testng.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;

public class Final_Project {
	WebDriver driver;
	public static HSSFWorkbook workbook;
	public static HSSFSheet worksheet;
	public static DataFormatter formatter = new DataFormatter();
	

	@DataProvider(name = "multipleTest")
	public Object[] ReadVariant() throws IOException {
		String file_location = "D:\\Study\\Selenium\\Data\\data4Test.xls";
		FileInputStream fileInputStream = new FileInputStream(file_location); // Excel sheet file location get mentioned
		String SheetName = "testCase02";																		// here
		workbook = new HSSFWorkbook(fileInputStream); // get my workbook
		worksheet = workbook.getSheet(SheetName);// get my sheet from workbook
		HSSFRow Row = worksheet.getRow(0); // get my Row which start from 0
		int RowNum = worksheet.getPhysicalNumberOfRows();// count my number of Rows
		System.out.println("Tong so hang " + RowNum);
		int maxColNum = Row.getLastCellNum(); // get last ColNum
		int minColNum = Row.getFirstCellNum(); // get first ColNum

	      Map<String, Integer> map = new HashedMap<String, Integer>() ;
	      for (int colIndx = minColNum; colIndx < maxColNum; colIndx++) {
	    	  HSSFCell cell= Row.getCell(colIndx);
	    	  map.put(cell.getStringCellValue(), cell.getColumnIndex());
	      }
	      int email = map.get("Email");
	      int pass = map.get("Pass");
	      int firstname = map.get("First Name");
	      int lastname = map.get("Last name");
	      int DAY_OF_BIRTH = map.get("DAY_OF_BIRTH");
	      int MONTH_OF_BIRTH = map.get("MONTH_OF_BIRTH");
	      int YEAR_OF_BIRTH = map.get("YEAR_OF_BIRTH");
	      int ADDRESS = map.get("ADDRESS");
	      int city = map.get("City");
	      int state = map.get("State");
	      int ZIPCODE = map.get("ZIPCODE");
	      int MOBILEPHONE = map.get("MOBILEPHONE");
	      int ALIAS = map.get("ALIAS");
      
      
//      System.out.println(maxColNum);
      	
		Object DataTemp[][] = new Object[RowNum][maxColNum]; // pass my count data in array
		List<DataTestDTO> listDataTestDTO = new ArrayList<DataTestDTO>();
		for (int iRow = 1; iRow < RowNum; iRow++) // Loop work for Rows
		{
			HSSFRow row = worksheet.getRow(iRow);
			DataTestDTO dataTestDTO = new DataTestDTO();
			dataTestDTO.setEmail(formatter.formatCellValue(row.getCell(email)));
			dataTestDTO.setPass(formatter.formatCellValue(row.getCell(pass)));
			dataTestDTO.setFirst_Name(formatter.formatCellValue(row.getCell(firstname)));
			dataTestDTO.setLast_name(formatter.formatCellValue(row.getCell(lastname)));
			dataTestDTO.setDAY_OF_BIRTH(formatter.formatCellValue(row.getCell(DAY_OF_BIRTH)));
			dataTestDTO.setMONTH_OF_BIRTH(formatter.formatCellValue(row.getCell(MONTH_OF_BIRTH)));
			dataTestDTO.setYEAR_OF_BIRTH(formatter.formatCellValue(row.getCell(YEAR_OF_BIRTH)));
			dataTestDTO.setADDRESS(formatter.formatCellValue(row.getCell(ADDRESS)));
			dataTestDTO.setCity(formatter.formatCellValue(row.getCell(city)));
			dataTestDTO.setState(formatter.formatCellValue(row.getCell(state)));
			dataTestDTO.setZIPCODE(formatter.formatCellValue(row.getCell(ZIPCODE)));
			dataTestDTO.setMOBILEPHONE(formatter.formatCellValue(row.getCell(MOBILEPHONE)));
			dataTestDTO.setALIAS(formatter.formatCellValue(row.getCell(ALIAS)));
			listDataTestDTO.add(dataTestDTO);
		}
		
		DataTestDTO[] arrayDataTestDTO = new DataTestDTO[listDataTestDTO.size()];

		for(int index = 0; index < listDataTestDTO.size(); index ++) {
			arrayDataTestDTO[index] = listDataTestDTO.get(index);
		}
		return arrayDataTestDTO;
	}

//TC01
	@Test(enabled = false, dataProvider = "multipleTest")
	public void createInvalidEmail(DataTestDTO dataTestDTO) {
		String webLink = "http://automationpractice.com/";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		Login login = home.clickLoginButton();
		login.createAccount(dataTestDTO);
		assert (login.isElementPresent(login.notification));
	}

	// TC02
	@Test(enabled = false, dataProvider = "multipleTest")
	public void creatEmail(DataTestDTO dataTestDTO) {
		String webLink = "http://automationpractice.com";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		Login login = home.clickLoginButton();
		AccountCreationPage creationPage = login.createAccount(dataTestDTO);
		MyAccount myAccount = creationPage.actionFillData(dataTestDTO);
		assert (myAccount.isElementPresent(myAccount.NOTIFICATION_ACC));
	}

	// TC03
	@Test(enabled = false)
	public void checkEmail() {
		String webLink = "https://www.guru99.com/selenium-tutorial.html";
		driver.get(webLink);
		driver.findElement(By.xpath("//*[@id=\"providence-field-email\"]")).sendKeys("selepracticel@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"providence-FieldsElementButton--C9kKY3pT6XjY37cXvyoM\"]")).click();
		driver.get("https://mail.google.com/mail/u/0/#inbox");
		driver.findElement(By.xpath(
				"//li[@class =\"h-c-header__nav-li g-mail-nav-links\"]/a[@class =\"h-c-header__nav-li-link \" and @ga-event-action = \"sign in\"]"))
				.click();
		ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(newTab.get(1));
		driver.findElement(By.xpath("//*[@id=\"identifierId\"]")).sendKeys("selepracticel@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"identifierNext\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input")).sendKeys("lqa12345");
		driver.findElement(By.xpath("//*[@id=\"passwordNext\"]")).click();
		try {
			driver.findElement(By.xpath(
					"//div[@class=\"Cp\"]//tr[1]//div[1]//span[@email = \"support@guru99.com\" and @data-hovercard-id =\"support@guru99.com\"]"));
			assert (true);
		} catch (Exception e) {
			// TODO: handle exception
			assert (false);
		}
	}

	// TC04
	@Test(enabled = false)
	public void checkEmailP2() {
		String webLink = "http://automationpractice.com";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		ContactPage contactPage = home.clickContactButton();
		ContactNotifPage conNotPage = contactPage.fillInfo();
		String actualNot = driver.findElement(conNotPage.NOTIF_MESS).getText();
		assertEquals(actualNot, conNotPage.messExpect);
	}

	// TC05
	@Test(enabled = false)
	public void checkSearchPlaceHolder() throws IOException, InterruptedException {
		String webLink = "http://automationpractice.com";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		System.out.println("Check place holder with text");
		assert (home.checkPlaceHolderText());
		System.out.println("Check place holder NO text");
		assert (home.checkPlaceHolderNoText());
	}

	// TC06.1
	@Test(enabled = false)
	public void searchkeyworkSuggestion() {
		String webLink = "http://automationpractice.com";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		home.checkKeywordSuggestion();
		assert (home.isElementPresent(home.SUGG_SEARCH_BOX));
	}

//TC06.2
	@Test(enabled = false)
	public void compareSuggAndActual() {
		String webLink = "http://automationpractice.com";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		home.checkKeywordSuggestion();
		List<WebElement> suggcount = driver.findElements(By.xpath("//*[@class = \"ac_results\"]//li"));
		int count = suggcount.size();
		for (int i = 0; i < suggcount.size(); i++) {
			By searchbox = By.xpath("//*[@class = \"ac_results\"]//li[" + (i + 1) + "]");
			home.getTextOfProd(searchbox);
//		System.out.println(home.nameprod);
			driver.findElement(searchbox).click();
			WebElement productname = driver.findElement(By.xpath("//*[@itemprop=\"name\"]"));
			String productnametext = productname.getText();
			assertEquals(productnametext, home.nameprod, "Sai o Suggestion thu: " + (i + 1));
			driver.navigate().back();
			home.checkKeywordSuggestion();
		}
	}

//TC06.3
	@Test(enabled = false)
	public void searchResult() throws InterruptedException {
		String webLink = "http://automationpractice.com";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		SearchResultPage searchprod = home.searchProduction();
		Thread.sleep(2000);
		searchprod.countprod();
		int total_prod = searchprod.searchresultcount.size();
		searchprod.getNumberOfProd(searchprod.NUMBER_OF_PROD_NOTIF);
		String number_result = searchprod.result_search;
		assertEquals(number_result, Integer.toString(total_prod));
	}

//TC06.4 
	@Test(enabled = false)
	public void checkPriceInfo() throws InterruptedException {
		String webLink = "http://automationpractice.com";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		SearchResultPage searchprod = home.searchProduction();
		Thread.sleep(2000);
		searchprod.countPrice();
		for (int i = 0; i < searchprod.searchresultcount.size(); i++) {
			By price = By
					.xpath("(//div[@class=\"right-block\"]//span[@class=\"price product-price\"])[" + (i + 1) + "]");
			assert (searchprod.isElementValue(price));
		}

	}

//TC07  
	@Test(enabled = false)
	public void checkNoSearchResult() {
		String webLink = "http://automationpractice.com";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		SearchResultPage searchprod = home.searchNoResult();
		searchprod.textNoResult();
		String actual_result = searchprod.textnoresult;
		String expect_result = "No results were found for your search " + "\"" + home.keywordsearch_noresult + "\"";

		assertEquals(actual_result, expect_result);
	}

	// TC08
	@Test(enabled = false)
	public void checkTotalPrice() throws InterruptedException {

		// Step 1: Open site
		String webLink = "http://automationpractice.com";
		driver.get(webLink);

		// Step 2: Login
		Homepage home = new Homepage(driver);
		Login login = home.clickLoginButton();
		MyAccount myacc = login.login();
		myacc.goHomePage();
		Thread.sleep(2000);

		// Step 3: Purchase
//	  System.out.println(home.addCart());
		Double total_price = home.addCart();

		// step 4 checkout
		ShoppingCart shopcart = home.checkOut();

		// Check if total payment if correct
		assertEquals(Double.toString(total_price), shopcart.getValuePrice());

		AddPage addpage = shopcart.checkOut();
		ShipPage shippage = addpage.clickCheckOut();
		PaymentMethodPage payment = shippage.clickCheckOut();
		payment.choosePayment();
//	  System.out.println(payment.getNotifAfterPay());

		// Check if mesage is displayed.
		assertEquals(payment.getNotifAfterPay(), "Your order on My Store is complete.");

	}

//TC09
	@Test(enabled = false)
	public void interrupCheckOut() throws InterruptedException {
		String webLink = "http://automationpractice.com";
		driver.get(webLink);
		Homepage home = new Homepage(driver);
		Login login = home.clickLoginButton();
		MyAccount myacc = login.login();
		myacc.goHomePage();
		Thread.sleep(2000);
		home.addCart2();
		ShoppingCart shopcart = home.checkOut();
	}

	@BeforeMethod
	public void beforeMethod() {
		System.setProperty("webdriver.chrome.driver", "D:\\Study\\Selenium\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@AfterMethod
	public void afterMethod() {
	}
}
